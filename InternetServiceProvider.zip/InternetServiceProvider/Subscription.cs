﻿using System.Text;

namespace InternetServiceProvider
{
    public class Subscription
    {
        public int Number { get; set; }
        public double Download { get; set; }
        public double Upload { get; set; }
        public DateOnly StartDate { get; set; }
        public DateOnly EndDate { get; set; }

        public Subscription(int number, double dowload, double upload)
        {
            Number = number;
            Download = dowload;
            Upload = upload;
        }

        public Subscription(int number, double download, double upload, DateOnly startDate, DateOnly endDate) 
            : this(number, download, upload)
        {
            StartDate = startDate;
            EndDate = endDate;
        }

        public override string ToString()
        {
            StringBuilder sb = new();
            sb.Append("Plan\n");
            sb.Append($"Nr planu {Number}\n");
            sb.Append($"Predkość pobierania: {Download} Mbit/s\n");
            sb.Append($"Predkość wysyłania: {Upload} Mbit/s\n");
            sb.Append($"Rozpoczęcie planu: {StartDate}\n");
            sb.Append($"Wygaśnięcie planu: {EndDate}\n");

            return sb.ToString();
        }
    }
}
