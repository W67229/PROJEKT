﻿using System.Text;

namespace InternetServiceProvider
{
    public class Client
    {
        private static int ClientCounter = 0;
        public int Number { get; set; }
        public string Name { get; set; }
        public string Surname { get; set; }
        public Address Address { get; set; }
        public ContactInfo ContactInfo { get; set; }
        public Subscription Subscription { get; set; }
        public List<Device> Devices { get; set; } = new();

        public Client(int number, string name, string surname, Address address, ContactInfo contactInfo, Subscription subscription)
        {
            Number = number;
            Name = name;
            Surname = surname;
            Address = address;
            ContactInfo = contactInfo;
            Subscription = subscription;
            ClientCounter++;
        }

        public Client(int number, string name, string surname, Address address, ContactInfo contactInfo, Subscription subscription, List<Device> devices)
        {
            Number = number;
            Name = name;
            Surname = surname;
            Address = address;
            ContactInfo = contactInfo;
            Subscription = subscription;
            Devices = devices;
        }

        public override string ToString()
        {
            StringBuilder sb = new();
            sb.Append($"Klient numer: {Number}\n");
            sb.Append("Podstawowe Informacje\n");
            sb.Append($"Imie: {Name}\n");
            sb.Append($"Nazwisko: {Surname} \n");
            sb.Append(Address.ToString());
            sb.Append(ContactInfo.ToString());
            sb.Append(Subscription.ToString());
            foreach(Device device in Devices)
            {
                sb.Append(device.ToString());
            }
            return sb.ToString();
        }
        public static int GetClientCounter()
        {
            return ClientCounter;
        }

        public static void SetClientCounter(int value)
        {
            ClientCounter = value;
        }
    }
}
