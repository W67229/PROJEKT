﻿namespace InternetServiceProvider
{
    public static class FileHandler
    {
        public static void SaveToFile(List<Client> clients, string path)
        {
            using (StreamWriter writer = new StreamWriter(path))
            {
                writer.WriteLine(Client.GetClientCounter());
                foreach (Client client in clients)
                {
                    writer.WriteLine(client.Number);
                    writer.WriteLine(client.Name);
                    writer.WriteLine(client.Surname);
                    writer.WriteLine(client.Address.Country);
                    writer.WriteLine(client.Address.City);
                    writer.WriteLine(client.Address.Street);
                    writer.WriteLine(client.Address.PropertyNumber);
                    writer.WriteLine(client.ContactInfo.Email);
                    writer.WriteLine(client.ContactInfo.PhoneNumber);
                    writer.WriteLine(client.Subscription.Number);
                    writer.WriteLine(client.Subscription.Download);
                    writer.WriteLine(client.Subscription.Upload);
                    writer.WriteLine(client.Subscription.StartDate);
                    writer.WriteLine(client.Subscription.EndDate);
                    writer.WriteLine(client.Devices.Count);
                    foreach (Device device in client.Devices)
                    {
                        writer.WriteLine(device.DeviceType);
                        writer.WriteLine(device.ToSave());
                    }
                }
            }
        }

        public static List<Client> LoadFromFile(string path)
        {
            List<Client> clients = new();
            using (StreamReader reader = new StreamReader(path))
            {
                if (reader.Peek() == -1)
                {
                    return clients;
                }
                int clientCounter, clientNumber, propertyNumber, subscriptionNumber, deviceCount;
                string name, surname, country, city, street, email, phoneNumber;
                double download, upload;
                DateOnly startDate, endDate;
                clientCounter = int.Parse(reader.ReadLine());
                Client.SetClientCounter(clientCounter);
                for (int i = 0; i < clientCounter; i++)
                {
                    clientNumber = int.Parse(reader.ReadLine());
                    name = reader.ReadLine();
                    surname = reader.ReadLine();
                    country = reader.ReadLine();
                    city = reader.ReadLine();
                    street = reader.ReadLine();
                    propertyNumber = int.Parse(reader.ReadLine());
                    Address address = new(country, city, street, propertyNumber);
                    email = reader.ReadLine();
                    phoneNumber = reader.ReadLine();
                    ContactInfo contactInfo = new(email, phoneNumber);
                    subscriptionNumber = int.Parse(reader.ReadLine());
                    download = double.Parse(reader.ReadLine());
                    upload = double.Parse(reader.ReadLine());
                    startDate = DateOnly.Parse(reader.ReadLine());
                    endDate = DateOnly.Parse(reader.ReadLine());
                    Subscription subscription = new(subscriptionNumber, download, upload, startDate, endDate);
                    deviceCount = 0;
                    List<Device> devices = new();
                    deviceCount = int.Parse(reader.ReadLine());
                    for (int j = 0; j < deviceCount; j++)
                    {
                        string deviceType = reader.ReadLine();
                        if (deviceType == "Router")
                        {
                            Guid deviceNumber = Guid.Parse(reader.ReadLine());
                            string ipAddress = reader.ReadLine();
                            Router router = new(deviceNumber, ipAddress);
                            devices.Add(router);
                        }
                    }
                    Client client = new(clientNumber, name, surname, address, contactInfo, subscription, devices);
                    clients.Add(client);
                }
            }
            return clients;
        }
    }
}
