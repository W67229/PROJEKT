﻿namespace InternetServiceProvider
{
    public abstract class Device
    {
        public Guid DeviceNumber { get; set; }
        public string DeviceType { get; set; }
        public abstract string ToSave();
    }
}
