﻿using System.Text;

namespace InternetServiceProvider
{
    public class Router : Device
    {
        public string IpAddress { get; set; }
       
        public Router(string ipAddress) 
        {
            DeviceNumber = Guid.NewGuid();
            DeviceType = "Router";
            IpAddress = ipAddress;
            
        }
        public Router(Guid deviceNumber, string ipAddress)
        {
            DeviceNumber = deviceNumber;
            DeviceType = "Router";
            IpAddress = ipAddress;

        }

        public override string ToString()
        {
            StringBuilder sb = new();
            sb.Append($"Ip rutera: {IpAddress}\n");
            sb.Append( $"Numer urządzenia: {DeviceNumber}\n");
            return sb.ToString();
        }

        public override string ToSave()
        {
            StringBuilder sb = new();
            sb.Append($"{DeviceNumber}\n");
            sb.Append($"{IpAddress}");
            return sb.ToString();
        }
    }
}
