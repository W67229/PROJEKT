﻿namespace InternetServiceProvider
{
    public static class Menu
    {
        public static void Print()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("1. Wyświetl klientów");
            Console.WriteLine("2. Dodaj nowego klienta");
            Console.WriteLine("3. Usuń klienta");
            Console.WriteLine("4. Edytuj klienta");
            Console.WriteLine("5. Zapisz i zakończ");
            Console.ResetColor();
        }
        public static void PrintUpdateSubMenu()
        {
            Console.WriteLine("1. Imię");
            Console.WriteLine("2. Nazwisko");
            Console.WriteLine("3. Kraj");
            Console.WriteLine("4. Miasto");
            Console.WriteLine("5. Ulica");
            Console.WriteLine("6. Numer lokalu");
            Console.WriteLine("7. Email");
            Console.WriteLine("8. Nr telefonu");
            Console.WriteLine("9. Plan subskrypcji");
            Console.WriteLine("10. Przedłuż umowę");
            Console.WriteLine("Podaj parametr który chcesz edytować: ");
        }
    }
}
