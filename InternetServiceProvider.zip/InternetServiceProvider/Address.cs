﻿using System.Text;

namespace InternetServiceProvider
{
    public class Address
    {
       
        public string Country { get; set; }
        public string City { get; set; }
        public string Street { get; set; }
        public int PropertyNumber { get; set; }

        public Address(string country, string city, string street, int propertyNumber)
        {
            Country = country;
            City = city;
            Street = street;
            PropertyNumber = propertyNumber;
        }
        public override string ToString()
        {
            StringBuilder sb = new(); 
            sb.Append("Adres\n");
            sb.Append($"Kraj: {Country} \n");
            sb.Append( $"Miasto: {City} \n" );
            sb.Append( $"Ulica: {Street}\n");
            sb.Append($"Nr lokalu: {PropertyNumber}\n");
            return sb.ToString();

        }

    }
}
