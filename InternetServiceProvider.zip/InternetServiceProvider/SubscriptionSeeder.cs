﻿namespace InternetServiceProvider
{
    public static class SubscriptionSeeder
    {
        public static List<Subscription> Seed()
        {
            return new List<Subscription>()
            {
                new(1 ,100,100),
                new(2 ,300,100),
                new(3, 1000,1000),
            };
        }
    }
}
