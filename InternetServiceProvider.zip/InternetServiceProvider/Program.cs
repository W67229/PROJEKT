﻿namespace InternetServiceProvider
{
    internal class Program
    {
        static void Main(string[] args)
        {
            App app = new();
            app.Run();
        }
    }
}
