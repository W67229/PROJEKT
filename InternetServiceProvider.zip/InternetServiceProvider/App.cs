﻿namespace InternetServiceProvider
{
    public class App
    {
        public List<Client> Clients { get; set; } = new();
        public List<Subscription> Subscriptions { get; set; }
        public App()
        {
            Subscriptions = SubscriptionSeeder.Seed();
            Clients = FileHandler.LoadFromFile("klienci.txt");
        }
        public void Run()
        {

            while (true)
            {
                Menu.Print();
                Console.Write("Wybór: ");
                string input = Console.ReadLine();
                Console.WriteLine();

                if (int.TryParse(input, out int choice))
                {
                    switch (choice)
                    {
                        case 1:
                            PrintClients();
                            break;
                        case 2:
                            AddClient();
                            break;
                        case 3:
                            RemoveClient();
                            break;
                        case 4:
                            UpdateClient();
                            break;
                        case 5:
                            FileHandler.SaveToFile(Clients, "klienci.txt");
                            return;
                        default:
                            Console.WriteLine("Nieprawidłowy wybór");
                            break;
                    }
                }
                else
                {
                    Console.WriteLine("Nieprawidłowy format. Wprowadź liczbę całkowitą.");
                }
                Console.WriteLine();
            }

        }
        private void AddClient()
        {
            string name, surname, country, city, street, email, phoneNumber;
            Console.WriteLine("Uzupełnij informacje");
            Console.Write("Imie: ");
            name = Console.ReadLine();
            Console.Write("Nazwisko: ");
            surname = Console.ReadLine();
            Console.Write("Kraj: ");
            country = Console.ReadLine();
            Console.Write("Miasto: ");
            city = Console.ReadLine();
            Console.Write("Ulica: ");
            street = Console.ReadLine();
            Console.Write("Podaj numer lokalu: ");
            string propertyNumberString = Console.ReadLine();
            int propertyNumber;
            while (!int.TryParse(propertyNumberString, out propertyNumber))
            {
                Console.Write("Numer musi być liczba całkowitą: ");
                propertyNumberString = Console.ReadLine();
            }
            Console.Write("Email: ");
            email = Console.ReadLine();
            Console.Write("Nr telefonu: ");
            phoneNumber = Console.ReadLine();
            Subscription subscription = ChoosePlan();
            Console.Write("Czy chcesz dodac urządzenie [T/N]: ");
            string choice = Console.ReadLine();
            while (choice != "T" && choice != "N")
            {
                Console.Write("Wprowadzono niepoprawna wartość: ");
                choice = Console.ReadLine();
            }
            Address address = new(country, city, street, propertyNumber);
            ContactInfo contactInfo = new(email, phoneNumber);
            Client client = new(Client.GetClientCounter() + 1, name, surname, address, contactInfo, subscription);
            if (choice == "T")
            {
                Console.WriteLine("Router zostal dodany");
                Router router = new("192.168.0.1");
                client.Devices.Add(router);
            }
            Clients.Add(client);
            Console.WriteLine("Klient został poprawnie dodany");

        }

        private Subscription ChoosePlan()
        {
            Console.WriteLine("Wybierz jeden z dostępnych planów");
            foreach (Subscription subscription in Subscriptions)
            {
                Console.WriteLine();
                Console.WriteLine($"Numer planu: {subscription.Number}");
                Console.WriteLine($"Download {subscription.Download} Mbit/s");
                Console.WriteLine($"Upload {subscription.Upload} Mbit/s");
                Console.WriteLine();
            }
            Console.Write("Wybór: ");
            string choice = Console.ReadLine();
            while (!int.TryParse(choice, out int choiceNumber) || !(choiceNumber > 0 && choiceNumber < 4))
            {
                Console.Write("Plan o takim numerze nie istnieje lub wprowadzona wartość nie jest liczbą całkowitą: ");
                choice = Console.ReadLine();
            }
            Subscription choosenSubscription = Subscriptions.First(s => s.Number == int.Parse(choice));
            choosenSubscription.StartDate = new DateOnly(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day);
            choosenSubscription.EndDate = choosenSubscription.StartDate.AddYears(1);
            return choosenSubscription;
        }

        private void PrintClients()
        {
            foreach (Client client in Clients)
            {
                Console.WriteLine(client.ToString());

            }
        }

        private void RemoveClient()
        {
            Console.WriteLine("0 - Powrót");
            Console.Write("Podaj numer klienta do usunięcia: ");
            string input = Console.ReadLine();
            int clientNumber;
            while (!int.TryParse(input, out clientNumber))
            {
                Console.Write("Wprowadzono niepoprawną wartość: ");
            }
            if (clientNumber == 0) { return; }
            Client toRemove = Clients.FirstOrDefault(c => c.Number == clientNumber);
            if (toRemove != null)
            {
                Clients.Remove(toRemove);
                Client.SetClientCounter(Clients.Count);
                Console.WriteLine("Klient został usunięty");
            }
            else
            {
                Console.WriteLine("Klient o takim numerze nie istnieje");
                RemoveClient();
            }

        }

        private void UpdateClient()
        {
            Console.WriteLine("0 - Powrót");
            Console.Write("Podaj numer klienta do edytowania: ");
            string input = Console.ReadLine();
            int clientNumber;
            while (!int.TryParse(input, out clientNumber))
            {
                Console.Write("Wprowadzono niepoprawną wartość: ");
            }
            if (clientNumber == 0) { return; }
            Client clientToEdit = Clients.FirstOrDefault(c => c.Number == clientNumber);
            if (clientToEdit == null)
            {
                Console.WriteLine("Klient o takim numerze nie istnieje");
                UpdateClient();
            }
            else
            {
                Menu.PrintUpdateSubMenu();
                input = Console.ReadLine();
                int choice;
                while (!int.TryParse(input, out choice))
                {
                    Console.Write("Wprowadzono niepoprawną wartość: ");
                }
                if (choice > 0 && choice < 9)
                {
                    Console.Write("Wprowadź nową wartość: ");
                    input = Console.ReadLine();
                }
                switch (choice)
                {
                    case 1:
                        clientToEdit.Name = input;
                        break;
                    case 2:
                        clientToEdit.Surname = input;
                        break;
                    case 3:
                        clientToEdit.Address.Country = input;
                        break;
                    case 4:
                        clientToEdit.Address.City = input;
                        break;
                    case 5:
                        clientToEdit.Address.Street = input;
                        break;
                    case 6:
                        int propertyNumber;
                        while (!int.TryParse(input, out propertyNumber))
                        {
                            Console.Write("Wprowadzono niepoprawną wartość: ");
                            input = Console.ReadLine();
                        }
                        clientToEdit.Address.PropertyNumber = propertyNumber;
                        break;
                    case 7:
                        clientToEdit.ContactInfo.Email = input;
                        break;
                    case 8:
                        clientToEdit.ContactInfo.PhoneNumber = input;
                        break;
                    case 9:
                        clientToEdit.Subscription = ChoosePlan();
                        break;
                    case 10:
                        Console.Write("Czy chcesz przedłużyć umowę [T/N]: ");
                        input = Console.ReadLine();
                        while (input != "T" && input != "N")
                        {
                            Console.Write("Wprowadzono niepoprawna wartość: ");
                            input = Console.ReadLine();
                        }
                        if(input == "T")
                        {
                            clientToEdit.Subscription.EndDate = clientToEdit.Subscription.EndDate.AddYears(1);
                            Console.WriteLine("Umowa została przedłużona");
                        }
                        break;
                    default:
                        Console.Write("Wprowadzono niepoprawną wartość: ");
                        break;
                }
            }
        }
    }
}
